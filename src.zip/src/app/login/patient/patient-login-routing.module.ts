import { NgModule } from "@angular/core";
import { Routes } from "@angular/router";
import { NativeScriptRouterModule } from "nativescript-angular/router";
import {PatientLoginComponent} from "~/app/login/patient/patient-login.component";

const routes: Routes = [
    {
        path: '',
        component: PatientLoginComponent,
    },
];

@NgModule({
    imports: [NativeScriptRouterModule.forChild(routes)],
    exports: [NativeScriptRouterModule]
})
export class PatientLoginRoutingModule { }
