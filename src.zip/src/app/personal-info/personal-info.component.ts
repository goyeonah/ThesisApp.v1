import {Component, ElementRef, OnInit, ViewChild, ViewContainerRef} from "@angular/core";
import {RouterExtensions} from "nativescript-angular";
import {of} from "rxjs";
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {TextField} from "tns-core-modules/ui/text-field";
import { AuthService } from "~/app/services/auth.service";
import {ActivatedRoute} from "@angular/router";

@Component({
    selector: "Home",
    moduleId: module.id,
    templateUrl: "./personal-info.component.html",
    styleUrls: ["./personal-info.component.css"]
})
export class PersonalInfoComponent implements OnInit {
    pageTitle: string;
    public currentUser: string;

    constructor(
        private router: RouterExtensions,
        private authService: AuthService,
        private activatedRoute: ActivatedRoute
    ) {
        this.activatedRoute.queryParams.subscribe( params => {
            this.currentUser = params["user"];
            console.log(this.currentUser);
        });
    }

    ngOnInit() {
    }

    goToBrowseRelevantInfo() {
        this.router.navigate(["relevantInfo"]).then();
    }

    goToReadings() {
        this.router.navigate(["readings"]).then();
    }

    goToPatientDailySigns() {
        this.router.navigate(["patient-daily-signs"]).then();
    }

    goToPersonalInfo() {
        this.router.navigate(["personal-info"]).catch();
    }

    goToAdmitData() {
        this.router.navigate(["admit-data"]).catch();
    }
    
    goToCoverSheet() {
        this.router.navigate(["cover-sheet"]).catch();
    }
    
    goToHistory() {
        this.router.navigate(["history"]).catch();
    }
    
    goToProfile() {
        this.router.navigate(["profile"]).catch();
    }
    
}
