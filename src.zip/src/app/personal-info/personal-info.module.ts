import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from "nativescript-angular/common";

import {ReactiveFormsModule} from "@angular/forms";
import {PersonalInfoComponent} from "~/app/personal-info/personal-info.component";
import { PersonalInfoRoutingModule } from "~/app/personal-info/personal-info-routing.module";

@NgModule({
    imports: [
        NativeScriptCommonModule,
        ReactiveFormsModule,
        PersonalInfoRoutingModule
    ],
    declarations: [
        PersonalInfoComponent
    ],
    schemas: [
        NO_ERRORS_SCHEMA
    ]
})
export class PersonalInfoModule { }
