import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from "nativescript-angular/common";

import {ReactiveFormsModule} from "@angular/forms";
import {CoverSheetComponent} from "~/app/cover-sheet/cover-sheet.component";
import { CoverSheetRoutingModule } from "~/app/cover-sheet/cover-sheet-routing.module";

@NgModule({
    imports: [
        NativeScriptCommonModule,
        ReactiveFormsModule,
        CoverSheetRoutingModule
    ],
    declarations: [
        CoverSheetComponent
    ],
    schemas: [
        NO_ERRORS_SCHEMA
    ]
})
export class CoverSheetModule { }
