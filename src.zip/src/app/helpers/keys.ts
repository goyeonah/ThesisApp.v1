export  const keys = {
    FIREBASE_API_KEY: "AIzaSyAs9xczR7h4Ut8q4HxOoqy2cm1cNj0TvgE",
    FIREBASE_APP_URL:"https://healthmobileapp-98c62.firebaseio.com",
    MESSAGE_CLIENT_URL: "",
    SIGNUP_URL: "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyAs9xczR7h4Ut8q4HxOoqy2cm1cNj0TvgE",
    SIGNIN_URL: "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyAs9xczR7h4Ut8q4HxOoqy2cm1cNj0TvgE",
};
