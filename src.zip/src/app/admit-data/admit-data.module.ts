import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from "nativescript-angular/common";

import {ReactiveFormsModule} from "@angular/forms";
import {AdmitDataComponent} from "~/app/admit-data/admit-data.component";
import { AdmitDataRoutingModule } from "~/app/admit-data/admit-data-routing.module";

@NgModule({
    imports: [
        NativeScriptCommonModule,
        ReactiveFormsModule,
        AdmitDataRoutingModule
    ],
    declarations: [
        AdmitDataComponent
    ],
    schemas: [
        NO_ERRORS_SCHEMA
    ]
})
export class AdmitDataModule { }
