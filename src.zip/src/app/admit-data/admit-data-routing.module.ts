import { NgModule } from "@angular/core";
import { Routes } from "@angular/router";
import { NativeScriptRouterModule } from "nativescript-angular/router";
import { AdmitDataComponent } from "~/app/admit-data/admit-data.component";

const routes: Routes = [
    {
        path: '',
        component: AdmitDataComponent,
    },
];

@NgModule({
    imports: [NativeScriptRouterModule.forChild(routes)],
    exports: [NativeScriptRouterModule]
})
export class AdmitDataRoutingModule { }
